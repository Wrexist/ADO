# AI Control Center — build package

Complete start-to-finish plan for your personal mission-control dashboard, recreating the two reference designs 1:1 and wiring in everything we've built (wrexist-ops, the loop patterns, the four extractions).

## Contents

| File | Purpose |
|---|---|
| MASTER_PLAN.md | Vision, architecture, 7 phases with gates, honest constraints |
| DESIGN_SPEC.md | 1:1 spec of both reference screens: tokens, layout, full component inventory |
| DATA_MAP.md | Every widget mapped to its real data source and the phase it goes live |
| SELF_LEARNING.md | The learn-by-itself loop: sense → analyze → propose → review → measure |
| CLAUDE.md | Drop at repo root — conventions incl. dynamic model routing + no-loops-on-copy |
| ops.yml | Drop at .claude/ops.yml — all 7 phase gates, data-integrity on |
| PROMPTS.md | 18 copy-paste Claude Code prompts, Phase 0 → 6 |

## Start (today, ~15 min)

1. `mkdir ai-control-center && cd` → git init → drop these files in (ops.yml → `.claude/ops.yml`)
2. Save the two reference PNGs as `design/reference/view-a.png` and `view-b.png`
3. Open Claude Code → run Prompt 0.1, then 0.2 (the council — don't skip it; it's the cheapest bug-fix of the whole project)

## What "done" looks like

Both views pixel-matched to the references but showing YOUR portfolio live: real repos, real CI, real agents you dispatch from the command box, real token spend — and a nightly analyzer filing improvement proposals whose worth is proven by two charts (success rate up, tokens per task down), not by claims.

## Two honest notes

**"1:1 and everything works"** are two gates, deliberately separate: Phase 1 delivers the exact look on mock data; Phases 2–5 make it true, widget by widget, per DATA_MAP. A few reference elements are intentionally honest placeholders in v1 (Billing, Team, Templates) — fake-working features would break the dashboard's own no-fabrication rule.

**This is project slot #4.** SENTINEL, the tower defense fun-gate, and the Dynasty Steam port all have open gates. The plan carries an anti-pivot clause (blocked phase > 1 week → stop and reassess), and the Friday sweeper watches this repo like the others. The dashboard is genuinely useful precisely because it will show you — on its own screen — every thread it's competing with.
