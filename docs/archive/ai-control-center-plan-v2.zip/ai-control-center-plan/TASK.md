# TASK.md — ai-control-center

## Open
- [ ] P0: run Prompt 0.1 (scaffold) — then /gate p0-foundation
- [ ] P0: run Prompt 0.2 council against the FINAL plan incl. AUDIT.md amendments
- [ ] Save reference PNGs to design/reference/ (view-a.png, view-b.png)
- [ ] Create .env from .env.example (GitHub PAT: repo+actions read; ACC token: `openssl rand -hex 24`)

## Decisions log
- 2026-07-07: plan v2 locked after 3-pass audit (see AUDIT.md). Canonical viewport 1536. View B descope lever named. Kill criterion accepted.

## Blocked
(none)
